const botonDato = document.getElementById("botonDato");
const datoHistorico = document.getElementById("datoHistorico");

botonDato.addEventListener("click", function () {
  const estaOculto = datoHistorico.hidden;
  datoHistorico.hidden = !estaOculto;
  botonDato.setAttribute("aria-expanded", String(estaOculto));
  botonDato.textContent = estaOculto
    ? "Ocultar dato histórico"
    : "Descubrir un dato histórico";
});
